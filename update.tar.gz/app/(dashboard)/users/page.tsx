'use client'

import { useEffect, useState } from 'react'
import { apiClient } from '@/lib/api-client'
import { useSession } from 'next-auth/react'
import { Plus, Search, UserCog, Shield, Users as UsersIcon, Trash2 } from 'lucide-react'
import { Modal } from '@/components/ui/Modal'
import { formatDate } from '@/lib/utils'
import { UserRouteModal } from '@/components/UserRouteModal'
import { MapPin } from 'lucide-react'

interface User {
  id: string; email: string; name: string; phone?: string; role: string
  status: string; teamId?: string; createdAt: string
  team?: { id: string; name: string }
  _count: { customers: number; opportunities: number; orders: number }
}

interface Team { id: string; name: string; _count: { users: number } }

type ApiUser = Partial<User> & {
  fullName?: string
  roles?: string[]
  isActive?: boolean
  deletedAt?: string | null
  _count?: Partial<User['_count']>
}

type ApiTeam = Partial<Team> & {
  _count?: Partial<Team['_count']>
}

const mapRole = (role?: string) => {
  const normalized = role?.toLowerCase()
  if (normalized === 'owner' || normalized === 'admin' || normalized === 'administrator') return 'ADMIN'
  if (normalized === 'manager' || normalized === 'sale_admin') return 'SALE_ADMIN'
  if (normalized === 'sale_lead') return 'SALE_LEAD'
  if (normalized === 'accountant') return 'ACCOUNTANT'
  if (normalized === 'sales') return 'SALES'
  return normalized ? normalized.toUpperCase() : 'UNKNOWN'
}

const normalizeUser = (user: ApiUser): User => ({
  id: user.id || '',
  email: user.email || '',
  name: user.name || user.fullName || user.email || '',
  phone: user.phone || '',
  role: mapRole(user.role || user.roles?.[0]),
  status: user.status || (user.isActive === false || user.deletedAt ? 'INACTIVE' : 'ACTIVE'),
  teamId: user.teamId,
  team: user.team,
  createdAt: user.createdAt || new Date().toISOString(),
  _count: {
    customers: user._count?.customers ?? 0,
    opportunities: user._count?.opportunities ?? 0,
    orders: user._count?.orders ?? 0,
  },
})

const normalizeTeam = (team: ApiTeam): Team => ({
  id: team.id || '',
  name: team.name || '',
  _count: { users: team._count?.users ?? 0 },
})

const ROLE_LABELS: Record<string, string> = { ADMIN: 'Admin', SALE_ADMIN: 'Sale Admin', SALE_LEAD: 'Sale Lead', SALES: 'Nhân viên Sale', ACCOUNTANT: 'Kế toán' }
const ROLE_COLORS: Record<string, string> = { ADMIN: 'bg-red-100 text-red-800', SALE_ADMIN: 'bg-purple-100 text-purple-800', SALE_LEAD: 'bg-indigo-100 text-indigo-800', SALES: 'bg-brand-100 text-blue-800', ACCOUNTANT: 'bg-emerald-100 text-emerald-800' }
const STATUS_LABELS: Record<string, string> = { ACTIVE: 'Hoạt động', ON_LEAVE: 'Nghỉ phép', INACTIVE: 'Ngừng HĐ' }
const STATUS_COLORS: Record<string, string> = { ACTIVE: 'bg-green-100 text-green-800', ON_LEAVE: 'bg-brand-100 text-amber-800', INACTIVE: 'bg-surface-100 text-surface-500' }

export default function UsersPage() {
  const { data: session } = useSession()
  const [users, setUsers] = useState<User[]>([])
  const [teams, setTeams] = useState<Team[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('')
  const [teamFilter, setTeamFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [showTeamModal, setShowTeamModal] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editUser, setEditUser] = useState<User | null>(null)
  const [routeUser, setRouteUser] = useState<User | null>(null)
  const [editTeam, setEditTeam] = useState<Team | null>(null)

  const [form, setForm] = useState({ name: '', email: '', password: '123456', phone: '', role: 'SALES', teamId: '', status: 'ACTIVE' })
  const [teamForm, setTeamForm] = useState({ name: '', description: '' })

  const fetchData = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (search) params.set('search', search)
      if (roleFilter) params.set('role', roleFilter)
      if (teamFilter) params.set('teamId', teamFilter)

      const [usersRes, teamsRes] = await Promise.all([
        apiClient.get(`/users?${params}`),
        apiClient.get('/teams'),
      ])
      const usersData = Array.isArray(usersRes) ? usersRes : (usersRes?.data ?? [])
      const teamsData = Array.isArray(teamsRes) ? teamsRes : (teamsRes?.data ?? [])
      setUsers(Array.isArray(usersData) ? usersData.map(normalizeUser) : [])
      setTeams(Array.isArray(teamsData) ? teamsData.map(normalizeTeam) : [])
    } catch (err) { console.error(err) }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchData() }, [search, roleFilter, teamFilter])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    const isEdit = !!editUser
    const url = isEdit ? `/users/${editUser.id}` : '/users'
    const method = isEdit ? 'PUT' : 'POST'
    // Map form fields to Core API DTO
    const mappedRole = form.role === 'ADMIN' ? 'admin' : 
                       form.role === 'SALE_ADMIN' ? 'sale_admin' : 
                       form.role === 'SALE_LEAD' ? 'sale_lead' : 
                       form.role === 'ACCOUNTANT' ? 'accountant' : 'sales'
    const baseBody = {
      fullName: form.name,
      phone: form.phone,
      roleNames: [mappedRole],
      teamId: form.teamId || null,
      isActive: form.status === 'ACTIVE'
    }
    const body = isEdit 
      ? { ...baseBody, email: form.email, username: form.email, ...(form.password ? { password: form.password } : {}) } 
      : { ...baseBody, email: form.email, password: form.password, username: form.email }

    try {
      await (method === 'POST' ? apiClient.post(url, body) : apiClient.put(url, body))
      setShowModal(false)
      setEditUser(null)
      setForm({ name: '', email: '', password: '123456', phone: '', role: 'SALES', teamId: '', status: 'ACTIVE' })
      fetchData()
    } catch (err: any) { alert(err.response?.data?.message || err.message || 'Có lỗi xảy ra') }
    finally { setSaving(false) }
  }

  const handleTeamSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      if (editTeam) {
        await apiClient.put(`/teams/${editTeam.id}`, teamForm)
      } else {
        await apiClient.post('/teams', teamForm)
      }
      setShowTeamModal(false); setEditTeam(null); setTeamForm({ name: '', description: '' }); fetchData()
    } catch { alert('Có lỗi xảy ra') }
    finally { setSaving(false) }
  }

  const handleDeleteTeam = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (!confirm('Bạn có chắc muốn xóa team này?')) return
    try {
      await apiClient.delete(`/teams/${id}`)
      fetchData()
    } catch (err: any) { alert(err.message || 'Có lỗi xảy ra') }
  }

  const handleEditTeam = (team: Team) => {
    setEditTeam(team)
    setTeamForm({ name: team.name, description: '' })
    setShowTeamModal(true)
  }

  const handleDeleteUser = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation()
    if (!confirm('Bạn có chắc muốn xóa nhân viên này? Dữ liệu sẽ không thể khôi phục.')) return
    try {
      const data = await apiClient.delete(`/users/${id}`)
      if (data?.message) alert(data.message)
      fetchData()
    } catch (err: any) { alert(err.message || 'Có lỗi xảy ra') }
  }

  const handleEdit = (user: User) => {
    setEditUser(user)
    setForm({ name: user.name, email: user.email, password: '', phone: user.phone || '', role: user.role, teamId: user.teamId || '', status: user.status })
    setShowModal(true)
  }

  const isAdmin = session?.user?.role === 'ADMIN'

  if (!isAdmin && session?.user?.role !== 'SALE_ADMIN') {
    return <div className="text-center py-12 text-surface-500"><Shield size={48} className="mx-auto mb-3 text-surface-300" /><p className="font-medium">Bạn không có quyền truy cập trang này</p></div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-surface-900">Quản lý nhân sự</h1>
          <p className="text-surface-500 text-sm mt-1">Quản lý đội ngũ kinh doanh và phân quyền</p>
        </div>
        {isAdmin && (
          <div className="flex gap-2">
            <button onClick={() => { setEditTeam(null); setTeamForm({ name: '', description: '' }); setShowTeamModal(true) }} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-surface-300 text-surface-700 rounded-lg text-sm font-medium hover:bg-surface-50">
              <UsersIcon size={16} /> Thêm team
            </button>
            <button onClick={() => { setEditUser(null); setForm({ name: '', email: '', password: '123456', phone: '', role: 'SALES', teamId: '', status: 'ACTIVE' }); setShowModal(true) }} className="flex items-center gap-2 px-4 py-2.5 btn-primary text-white rounded-lg text-sm font-medium">
              <Plus size={16} /> Thêm nhân viên
            </button>
          </div>
        )}
      </div>

      {/* Teams Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {teams.map(team => (
          <div key={team.id} onClick={() => isAdmin ? handleEditTeam(team) : null} className={`bg-white rounded-xl p-4 shadow-sm border border-surface-100 transition-shadow ${isAdmin ? 'cursor-pointer hover:shadow-md hover:border-brand-200' : ''}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-surface-900 group-hover:text-brand-600">{team.name}</h3>
                {isAdmin && <button onClick={(e) => handleDeleteTeam(team.id, e)} className="p-1 hover:bg-red-50 text-red-500 rounded"><Trash2 size={14} /></button>}
              </div>
              <span className="text-sm text-surface-500">{team._count.users} thành viên</span>
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {users.filter(u => u.teamId === team.id).map(u => (
                <span key={u.id} className="text-xs px-2 py-1 bg-brand-50 text-brand-700 rounded">{u.name}</span>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl p-4 shadow-sm flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-surface-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Tìm nhân viên..." className="w-full pl-9 pr-4 py-2 border border-surface-200 rounded-lg text-sm" />
        </div>
        <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} className="border border-surface-200 rounded-lg px-3 py-2 text-sm">
          <option value="">Vai trò</option>
          {Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <select value={teamFilter} onChange={e => setTeamFilter(e.target.value)} className="border border-surface-200 rounded-lg px-3 py-2 text-sm">
          <option value="">Tất cả team</option>
          {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <table className="w-full data-table">
          <thead>
            <tr><th>Tên</th><th>Email</th><th>SĐT</th><th>Vai trò</th><th>Team</th><th>Trạng thái</th><th>KH</th><th>Cơ hội</th><th>ĐH</th><th>Ngày tạo</th><th></th></tr>
          </thead>
          <tbody>
            {loading ? (
              [...Array(5)].map((_, i) => <tr key={i}>{[...Array(10)].map((_, j) => <td key={j}><div className="h-4 bg-surface-100 rounded animate-pulse" /></td>)}</tr>)
            ) : users.length === 0 ? (
              <tr><td colSpan={10} className="text-center py-12 text-surface-400"><UserCog size={48} className="mx-auto mb-3 text-surface-300" /><p>Chưa có nhân viên</p></td></tr>
            ) : (
              users.map(user => (
                <tr key={user.id} onClick={() => isAdmin ? handleEdit(user) : null} className={isAdmin ? 'cursor-pointer hover:bg-brand-50/50' : ''}>
                  <td className="font-medium">{user.name}</td>
                  <td className="text-sm">{user.email}</td>
                  <td className="text-sm">{user.phone || '-'}</td>
                  <td><span className={`badge ${ROLE_COLORS[user.role] || 'bg-gray-100 text-gray-800'}`}>{ROLE_LABELS[user.role] || user.role}</span></td>
                  <td className="text-sm">{user.team?.name || '-'}</td>
                  <td><span className={`badge ${STATUS_COLORS[user.status]}`}>{STATUS_LABELS[user.status]}</span></td>
                  <td className="text-center">{user._count.customers}</td>
                  <td className="text-center">{user._count.opportunities}</td>
                  <td className="text-center">{user._count.orders}</td>
                  <td className="text-sm text-surface-500">{formatDate(user.createdAt)}</td>
                  <td>
                    {isAdmin && session?.user?.id !== user.id && (
                      <div className="flex items-center gap-1">
                        <button onClick={(e) => { e.stopPropagation(); setRouteUser(user) }} className="p-1.5 hover:bg-blue-50 text-blue-600 rounded" title="Xem tua tuyến">
                          <MapPin size={14} />
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); handleEdit(user) }} className="p-1.5 hover:bg-brand-50 text-brand-600 rounded" title="Sửa nhân viên">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                        </button>
                        <button onClick={(e) => handleDeleteUser(user.id, e)} className="p-1.5 hover:bg-red-50 text-red-600 rounded" title="Xóa nhân viên">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit User Modal */}
      <Modal isOpen={showModal} onClose={() => { setShowModal(false); setEditUser(null) }} title={editUser ? 'Sửa thông tin nhân viên' : 'Thêm nhân viên mới'}>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-surface-700 mb-1">Họ tên *</label>
            <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} required className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-surface-700 mb-1">Email *</label>
            <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} required className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-surface-700 mb-1">{editUser ? 'Đổi mật khẩu' : 'Mật khẩu *'}</label>
              <input value={form.password} onChange={e => setForm({...form, password: e.target.value})} required={!editUser} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" placeholder={editUser ? 'Để trống nếu không đổi' : '123456'} />
            </div>
            <div>
              <label className="block text-sm font-medium text-surface-700 mb-1">SĐT</label>
              <input value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-surface-700 mb-1">Vai trò</label>
              <select value={form.role} onChange={e => setForm({...form, role: e.target.value})} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm">
                {Object.entries(ROLE_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-surface-700 mb-1">Team</label>
              <select value={form.teamId} onChange={e => setForm({...form, teamId: e.target.value})} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm">
                <option value="">Chọn team</option>
                {teams.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
          </div>
          {editUser && (
            <div>
              <label className="block text-sm font-medium text-surface-700 mb-1">Trạng thái</label>
              <select value={form.status} onChange={e => setForm({...form, status: e.target.value})} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm">
                {Object.entries(STATUS_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          )}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={() => { setShowModal(false); setEditUser(null) }} className="flex-1 py-2 border border-surface-300 rounded-lg text-sm hover:bg-surface-50">Hủy</button>
            <button type="submit" disabled={saving} className="flex-1 py-2 btn-primary text-white rounded-lg text-sm font-medium disabled:opacity-50">
              {saving ? 'Đang lưu...' : editUser ? 'Cập nhật' : 'Thêm'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Add/Edit Team Modal */}
      <Modal isOpen={showTeamModal} onClose={() => { setShowTeamModal(false); setEditTeam(null) }} title={editTeam ? 'Cập nhật thông tin team' : 'Thêm team mới'}>
        <form onSubmit={handleTeamSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-surface-700 mb-1">Tên team *</label>
            <input value={teamForm.name} onChange={e => setTeamForm({...teamForm, name: e.target.value})} required className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" placeholder="VD: Team Khu vực Đà Nẵng" />
          </div>
          <div>
            <label className="block text-sm font-medium text-surface-700 mb-1">Mô tả</label>
            <textarea value={teamForm.description} onChange={e => setTeamForm({...teamForm, description: e.target.value})} className="w-full border border-surface-300 rounded-lg px-3 py-2 text-sm" rows={3} />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={() => { setShowTeamModal(false); setEditTeam(null) }} className="flex-1 py-2 border border-surface-300 rounded-lg text-sm hover:bg-surface-50">Hủy</button>
            <button type="submit" disabled={saving} className="flex-1 py-2 btn-primary text-white rounded-lg text-sm font-medium disabled:opacity-50">{saving ? 'Đang lưu...' : editTeam ? 'Cập nhật' : 'Tạo team'}</button>
          </div>
        </form>
      </Modal>
      {/* Route Modal */}
      {routeUser && (
        <UserRouteModal 
          isOpen={!!routeUser} 
          onClose={() => setRouteUser(null)} 
          userId={routeUser.id} 
          userName={routeUser.name} 
        />
      )}
    </div>
  )
}
